
// #Day1 // Yiğit BAL // 11.03.2024

import UIKit

var greeting = "Hello, playground"

// 1) Variables

greeting = "GoodBye"

// Var could be change after you name it whatever.

// If we created variable, we can change it after all whenever we want to change.

var FavoriteShow = "Orange is New Black"

FavoriteShow = "BreakingBad"

FavoriteShow = "Friends"

// As you can see , we can  change it smoothly if we created variable function once.


// 2) String and Integer

var age = 32

var population = 85_000_000

var MeaningOfLife = 42

// MeaningOfLife = "Fourty two"  // We have an alert for here that put it string instead of int.

// you can see easily, we cannot assign for string instead of integer.

// 3) Multi-Line Strings

var srt1 = """
Bla Bla Bla \
Bla Bla Bla \
Bla Bla Bla
"""

var str3 = "you can change the world by yourself"

var str4 = """
you /
can /
change /
the /
world
"""

//str4 = str4.replacingOccurrences(of: "\n", with: "")
//print(str4)

// 4) Doubles and Booleans

var pi = 3.141

var awesome = true

print(awesome)

print (pi)

var MyInt = 1.0 // if here 1 , we can't plus int and double, swift does not allowed it.

var MyDouble = 1.0

var Total = MyInt + MyDouble

// Normally We can plus int and double but if we change int number 1 into 1.0 , that is able to plus together ,
// because those of two which are int and double changed into both double , thats the way we calculated as 2 .


// 5) String Interpolation

var score = 99

var StrScore = "Your score is \(score)"

var score2 = 999

var StrScore2 = "Your score was: \(score2)"

var YourCity = "İzmir"

var mesaj = "\(YourCity)'e HoşGeldiniz!"

// 6) Constants (Let)

let Taylor = "Swift"

//Taylor = "swift" // As you can see , we cannot change constants !!!

// 7) Type Annotation

let album: String = "Reputation"
let year: Int = 1989
let height: Double = 1.78
let taylorRocs: Bool = true

let Name: String = "Yiğit"
let Surname: String = "BAL"
let BirthYear: Int = 1992
let yiğitBal: Bool = true
















